<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ppitax_model extends CI_Model {

    public function saveppitaxuser($data){
      $sql_check =  $this->db->where('phone',$data['phone'])->where('email',$data['email'])->get('taxuser');
    //   return $sql_check->num_rows();
    //   return;
    if($sql_check->num_rows() > 0){
        $query=$this->db->select('*')->where('email',$data['email'])->get('taxuser');
        return $query->row();
    }else{
        $sql_check =  $this->db->where('phone',$data['phone'])->get('taxuser');
        if($sql_check->num_rows() > 0){
            $this->session->set_flashdata('error', 'Phone Number already exists');
            redirect(base_url());
            return;
        }
        $sql_check =  $this->db->where('email',$data['email'])->get('taxuser');
        if($sql_check->num_rows() > 0){
            $this->session->set_flashdata('error', 'Email already exists');
            redirect(base_url());
            return;
        }
        $sql_query = $this->db->insert('taxuser',$data);
        if($sql_query){
            $query=$this->db->select('*')->where('email',$data['email'])->get('taxuser');
            return $query->row();
            // return $this->db->insert_id();
        }else{
            return false;
        }
    }
       
    }

    public function checkadmin($data){
        $sql_check =  $this->db->where('user_name',$data['user_name'])->where('password',$data['password'])->get('users');
        if($sql_check->num_rows() > 0){
            // print_r($sql_check);
            return $sql_check->row();
        }else{
            // print_r($sql_check);
            return $sql_check->num_rows();
        }
    }
    
    public function saveppitaxuserdetails($data){
        $sql_query = $this->db->insert('taxuser_personaldetails',$data);
        if($sql_query){
            return true;
        }
    }

    public function saveppi_payout_details($data){
        $sql_query = $this->db->insert('taxuser_ppipayou_details_tbl',$data);
        if($sql_query){
            return true;
        }
    }
    
    public function savtax_income_details($data){
        $sql_query = $this->db->insert('bank_income_details_tbl',$data);
        if($sql_query){
            return true;
        }
    }

    public function gettaxformdata(){
        $query=$this->db->select('*')->get('taxuser_personaldetails');
             return $query->result();
    }

    public function getusercount(){
        $query=$this->db->select('*')->get('taxuser');
        return $query->result();
    }
    public function taxuser_personaldetails_count (){
        $query=$this->db->select('*')->get('taxuser_personaldetails');
        return $query->result();
    }

            public function  gettaxalldata($id){
                $this->db->select ( '*' ); 
    $this->db->from ( 'taxuser_personaldetails' );
    $this->db->join ( 'taxuser_ppipayou_details_tbl', 'taxuser_ppipayou_details_tbl.u_id = taxuser_personaldetails.u_id', 'left' );
    $this->db->join ( 'bank_income_details_tbl', 'bank_income_details_tbl.u_id =taxuser_personaldetails.u_id', 'left' );
    $this->db->where('taxuser_personaldetails.id', $id);
    $query = $this->db->get ();
    return $query->result();
            }
}