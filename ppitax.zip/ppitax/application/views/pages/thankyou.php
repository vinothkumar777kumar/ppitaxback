<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><META http-equiv="Content-Type" content="text/html; charset=UTF-8" >
<title>PPITACBACK</title>
    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/images/logo/1.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/1.png">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="robots" content="noindex, nofollow"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="lp-version" content="v6.21.10">
<style title="page-styles" type="text/css" data-page-type="main_desktop">
body {
 color:#666;
}
a {
 color:#36b3a8;
 text-decoration:none;
}
#lp-pom-image-380 {
 left:472px;
 top:2px;
 display:block;
 background:rgba(255,255,255,0);
 z-index:4;
 position:absolute;
}
#lp-pom-text-424 {
 left:315.5px;
 top:656.666748046875px;
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 z-index:1;
 width:569px;
 height:22px;
 position:absolute;
}
#lp-pom-text-427 {
 left:198px;
 top:794px;
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 z-index:2;
 width:310px;
 height:44px;
 position:absolute;
}
#lp-pom-root {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 margin:auto;
 padding-top:0px;
 border-radius:0px;
 min-width:1200px;
 height:728px;
}
#lp-pom-block-376 {
 display:block;
 background:rgba(255,255,255,0.2);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:16px;
 border-radius:0px;
 width:1200px;
 height:121px;
 position:relative;
}
#lp-pom-block-392 {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none none none none;
 border-width:undefinedpx;
 border-color:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:61px;
 border-radius:0px;
 width:100%;
 height:412px;
 position:relative;
}
#lp-pom-text-450 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:450px;
 top:192px;
 z-index:5;
 width:300px;
 height:25px;
 position:absolute;
}
#lp-pom-text-451 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:214px;
 top:343px;
 z-index:3;
 width:771px;
 height:204px;
 position:absolute;
}
#lp-pom-image-461 {
 display:block;
 background:rgba(255,255,255,0);
 left:560px;
 top:236px;
 z-index:6;
 position:absolute;
}
#lp-pom-block-423 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:118px;
 position:relative;
}
#lp-pom-root .lp-positioned-content {
 top:0px;
 width:1200px;
 margin-left:-600px;
}
#lp-pom-block-376 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:121px;
}
#lp-pom-block-392 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:412px;
}
#lp-pom-image-380 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:256px;
 height:117px;
}
#lp-pom-image-380 .lp-pom-image-container img {
 width:256px;
 height:117px;
}
#lp-pom-block-423 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:118px;
}
#lp-pom-image-461 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:80px;
 height:79px;
}
#lp-pom-image-461 .lp-pom-image-container img {
 width:80px;
 height:79px;
}
#lp-pom-root-color-overlay {
 position:absolute;
 background:none;
 top:0;
 width:100%;
 height:728px;
 min-height:100%;
}
#lp-pom-block-376-color-overlay {
 position:absolute;
 background:none;
 height:121px;
 width:1200px;
}
#lp-pom-block-392-color-overlay {
 position:absolute;
 background:none;
 height:412px;
 width:100%;;
}
#lp-pom-block-423-color-overlay {
 position:absolute;
 background:none;
 height:118px;
 width:100%;;
}
</style><style title="page-styles" type="text/css" data-page-type="main_mobile">
@media only screen and (max-width: 600px) {
#lp-pom-root {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 margin:auto;
 padding-top:0px;
 border-radius:0px;
 min-width:320px;
 height:914px;
}
#lp-pom-block-376 {
 display:block;
 background:rgba(255,255,255,0.2);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:62px;
 border-radius:0px;
 width:320px;
 height:111px;
 position:relative;
}
#lp-pom-image-380 {
 display:block;
 background:rgba(255,255,255,0);
 left:43px;
 top:1px;
 z-index:4;
 position:absolute;
}
#lp-pom-block-392 {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none none none none;
 border-width:undefinedpx;
 border-color:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:59px;
 border-radius:0px;
 width:100%;
 height:545px;
 position:relative;
}
#lp-pom-text-450 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:0px;
 top:197px;
 z-index:5;
 width:300px;
 height:25px;
 transform:scale(1.05);
 transform-origin:0 0;
 -webkit-transform:scale(1.05);
 -webkit-transform-origin:0 0;
 position:absolute;
}
#lp-pom-text-451 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:9px;
 top:366px;
 z-index:3;
 width:301px;
 height:360px;
 position:absolute;
}
#lp-pom-image-461 {
 display:block;
 background:rgba(255,255,255,0);
 left:120px;
 top:262px;
 z-index:6;
 position:absolute;
}
#lp-pom-text-424 {
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:10px;
 top:787px;
 z-index:1;
 width:284px;
 height:44px;
 position:absolute;
}
#lp-pom-text-427 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:26px;
 top:813px;
 z-index:2;
 width:252px;
 height:66px;
 position:absolute;
}
#lp-pom-block-423 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:137px;
 position:relative;
}
body {
 color:#666;
}
a {
 color:#36b3a8;
 text-decoration:none;
}
#lp-pom-root .lp-positioned-content {
 top:0px;
 width:320px;
 margin-left:-160px;
}
#lp-pom-block-376 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:111px;
}
#lp-pom-block-392 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:545px;
}
#lp-pom-image-380 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:234px;
 height:107px;
}
#lp-pom-image-380 .lp-pom-image-container img {
 width:234px;
 height:107px;
}
#lp-pom-block-423 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:137px;
}
#lp-pom-image-461 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:80px;
 height:79px;
}
#lp-pom-image-461 .lp-pom-image-container img {
 width:80px;
 height:79px;
}
#lp-pom-root-color-overlay {
 position:absolute;
 background:none;
 top:0;
 width:100%;
 height:914px;
 min-height:100%;
}
#lp-pom-block-376-color-overlay {
 position:absolute;
 background:none;
 height:111px;
 width:320px;
}
#lp-pom-block-392-color-overlay {
 position:absolute;
 background:none;
 height:545px;
 width:100%;;
}
#lp-pom-block-423-color-overlay {
 position:absolute;
 background:none;
 height:137px;
 width:100%;;
}
}
</style><!-- lp:insertions start head -->
<link href="<?php echo base_url()?>assets/bootstrap/css/main.css" rel="stylesheet" media="screen" type="text/css" />
<meta property='og:title' content=''/>
<script type="text/javascript">window.ub = {"page":{"id":"9b5402f6-4297-4c44-8162-0241ecfb8cf3","variantId":"a","usedAs":"main","name":"PPI TAX REBATE BACK copy 2","url":"http://www.digitalfsg.com/thankyou/","dimensions":{"desktop":{"height":728,"width":1200},"mobile":{"height":914,"width":320},"mobileMaxWidth":600}},"hooks":{"beforeFormSubmit":[],"afterFormSubmit":[]}};</script><script>window.ub.page.webFonts = ['PT Sans:regular'];</script><!-- lp:insertions end head -->
</head>
<body class="lp-pom-body"><!-- lp:insertions start body:before --><!-- lp:insertions end body:before -->
<div class="lp-element lp-pom-root" id="lp-pom-root"><div id="lp-pom-root-color-overlay"></div>
<div class="lp-positioned-content"><div class="lp-element lp-pom-image" id="lp-pom-image-380"><div class="lp-pom-image-container" style="overflow: hidden;">
	<img src="<?php echo base_url()?>assets/images/logo/logo-desktop-1x.png" alt="" data-src-desktop-1x="<?php echo base_url()?>assets/images/logo/logo-desktop-1x.png" 
	data-src-desktop-2x="<?php echo base_url()?>assets/images/logo/logo-desktop-1x.png" 
	data-src-mobile-1x="<?php echo base_url()?>assets/images/logo/logo-desktop-1x.png" 
	data-src-mobile-2x="<?php echo base_url()?>assets/images/logo/logo-desktop-1x.png">
</div></div><div class="lp-element lp-pom-text nlh" id="lp-pom-text-424"><p><span style="color: rgb(255, 255, 255); font-size: 14px;">© 2020 All Rights Reserved | ppitaxback.org is a trading style of Dodl Holdings Limited. </span></p></div><div class="lp-element lp-pom-text nlh" id="lp-pom-text-427"><p style="text-align: center;"><span style="font-size: 16px; font-family: &quot;PT Sans&quot;; color: rgb(255, 255, 255);">© 2020 All Rights Reserved | ppitaxback.org is a trading style of Dodl Holdings Limited.&nbsp;</span></p></div><div class="lp-element lp-pom-text nlh" id="lp-pom-text-450"><h2 data-element-type="paragraph" data-uialign="left" style="text-align: center;">
<span style="font-size: 36px; background-color: rgb(255, 255, 255);">THANK YOU!</span></h2></div>

<div class="lp-element lp-pom-text nlh" id="lp-pom-text-451">
	<div style="text-align:center">
<a class="btn btn-primary" href="<?php echo base_url()?>">Back To Login</a>
</div>
<p style="line-height: 26px; text-align: center;"><span style="font-size: 20px;">Your Tax Claim Case has been logged with our Expert Advisers and we will contact you within the next 24 hours to confirm some key information</span></p><p style="line-height: 26px; text-align: center;"><span style="font-size: 20px;">We will call from 000000000000000</span></p><p style="line-height: 26px; text-align: center;"><span style="font-size: 20px;">If you could have your PPI Settlement Letter(s) ready that would be great Don’t worry if you can’t find them&nbsp;</span></p><p style="line-height: 26px;"><br></p></div><div class="lp-element lp-pom-image" id="lp-pom-image-461"><div class="lp-pom-image-container" style="overflow: hidden;">
<img src="<?php echo base_url()?>assets/images/img/tick.png" alt="" 
data-src-desktop-1x="<?php echo base_url()?>assets/images/img/tick.png" 
data-src-desktop-2x="<?php echo base_url()?>assets/images/img/tick.png" 
data-src-mobile-1x="<?php echo base_url()?>assets/images/img/tick.png" 
data-src-mobile-2x="<?php echo base_url()?>assets/images/img/tick.png">
</div></div></div>

<div class="lp-element lp-pom-block" id="lp-pom-block-376"><div id="lp-pom-block-376-color-overlay"></div><div class="lp-pom-block-content"></div></div><div class="lp-element lp-pom-block" id="lp-pom-block-392"><div id="lp-pom-block-392-color-overlay"></div><div class="lp-pom-block-content"></div></div><div class="lp-element lp-pom-block" id="lp-pom-block-423"><div id="lp-pom-block-423-color-overlay"></div><div class="lp-pom-block-content"></div></div></div>

<!-- lp:insertions start body:after --><script async src="//builder-assets.unbounce.com/published-js/main.bundle-81f56cf.z.js" type="text/javascript"></script>
</body>
</html>