<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PPITAXBACK</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/images/logo/2.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/2.png">



    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/cs-skin-elastic.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/normalize.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/font-awesome.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/style_ad.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/datatable/dataTables.bootstrap.min.css');?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
    <!-- Left Panel -->
<!-- <?php
print_r($data);
?> -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="<?php echo base_url();?>index.php/welcome/dasboard"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                  
                    <li>
                        <a href="<?php echo 'view_tax';?>"> <i class="menu-icon fa fa-cogs"></i>Tax List</a>
                    </li>
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                <a class="navbar-brand" href="./"><img style="height:38px;width:100px" src="<?php echo base_url();?>assets/images/logo/2.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="<?php echo base_url();?>assets/images/img/admin.jpg"alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
                   

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo base_url();?>assets/images/img/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <!-- <a class="nav-link" href="#"><i class="fa fa-user"></i>My Profile</a>

                            <a class="nav-link" href="#"><i class="fa fa-bell-o"></i>Notifications <span class="count">13</span></a>

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i>Settings</a> -->

                            <a class="nav-link"href="<?php echo base_url();?>index.php/welcome/logout"><i class="fa fa-power-off"></i>Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Tax List</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                <li><a href="<?php echo base_url().'index.php/welcome/dasboard';?>">Dashboard</a></li>
                                    <li><a href="<?php echo base_url().'index.php/welcome/view_tax';?>">Tax</a></li>
                                    <li class="active">Tax List</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Tax List</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                        <th>S.No</th>
                                            <th>Full Name</th>
                                            <!-- <th>DOB</th> -->
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <!-- <th>Address</th> -->
                                            <!-- <th>View</th> -->
                                            <!-- <th>Action</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                                        <?php 
                                         $i = 0;
                                        foreach($data as $d){
                                             
                                            ?>
                                        
                                        <tr>
                                           <td><?php echo $i + 1;?></td>
                                            <td><?php echo $d->name;?></td>
                                            <!-- <td><?php echo date('d-m-Y',strtotime($d->dob))?></td> -->
                                            <td><?php echo $d->phone;?></td>
                                            <td><?php echo $d->email;?></td>
                                            <!-- <td><?php echo $d->address?></td> -->
                                            <!-- <td>
                                                <a href="<?php echo 'view_more'.'/'.$d->id;?>"><i class="fa fa-eye"></i></a>
                                            </td> -->
                                            <!-- <td><a href="<?php echo '';?>"><i class="fa fa-view"></i></a></td> -->
                                        </tr>
                                        <?php
                                    $i++;
                                    }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>

       

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/main.js"></script>



    <script src="<?php echo base_url();?>assets/jquery/data-table/datatables.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/jszip.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/vfs_fonts.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/data-table/buttons.colVis.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/init/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>


</body>
</html>
