<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PPITAXBACK</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/images/logo/2.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/2.png">

    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/lib/datatable/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css"> -->

    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/cs-skin-elastic.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/normalize.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/font-awesome.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/style_ad.css');?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link href="<?php echo base_url();?>assets/bootstrap/css/style.css" rel="stylesheet" media="screen" type="text/css" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
    <!-- Left Panel -->
<?php
// print_r($data);
?>
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="<?php echo base_url();?>index.php/welcome/dasboard"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                  
                    <li>
                        <a href="<?php echo base_url()?>index.php/welcome/view_tax"> <i class="menu-icon fa fa-cogs"></i>Tax List</a>
                    </li>
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                <a class="navbar-brand" href="./"><img style="height:38px;width:100px" src="<?php echo base_url();?>assets/images/logo/2.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">
      

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo base_url();?>assets/images/img/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <!-- <a class="nav-link" href="#"><i class="fa fa-user"></i>My Profile</a>

                            <a class="nav-link" href="#"><i class="fa fa-bell-o"></i>Notifications <span class="count">13</span></a>

                            <a class="nav-link" href="#"><i class="fa fa-cog"></i>Settings</a> -->

                            <a class="nav-link" href="<?php echo base_url();?>index.php/welcome/logout"><i class="fa fa-power-off"></i>Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Tax View</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="<?php echo base_url().'index.php/welcome/dasboard';?>">Dashboard</a></li>
                                    <li><a href="<?php echo base_url().'index.php/welcome/view_tax';?>">Tax</a></li>
                                    <li class="active">Tax View</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Tax Form</strong>
                            </div>
                            <div class="card-body">
                            <form  action ="<?php echo 'addformdata'?>" method="POST" id="taxformuserdata">
            <input type="hidden" name='u_id' value="<?php echo 'fh'?>" />
                <div class="row"> 
                    <div class="col-lg-8">
                        <img src="<?php echo base_url();?>assets/images/logo/2.png" alt="logo" />
                        <div class="userdetail">
                            <div class="userfiel">
                                <span>Enter Name : </span> <?php echo $data[0]->fullname;?>
                            </div>
                            <div class="userfiel">
                                <span>Enter Address :</span>  <?php echo $data[0]->address;?>
                            </div>
                            <div class="userfiel">
                                <span></span>
                            </div>
                            <div class="userfiel">
                                <span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center">
                        <h5>TAX REBATE PROCESSING</h5>
                        <div class="number">
                            <span>*1245677*</span>
                        </div>
                        <span>FORM 1</span>
                    </div>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th colspan="2" style="background-color: #ddd;">
                                    <b>1.MY DETAILS</b>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Full Name</span>
                                        </div>
                                        <input type="text" class="form-control alpha" value="<?php echo $data[0]->fullname;?>" name="fullname" id="fullname" required>
                                    </div>
                                    
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">D.O.B</span>
                                        </div>
                                        <input type="date" class="form-control"  name="dob" id="dob" required value="<?php echo $data[0]->dob;?>"
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Primary phone</span>
                                        </div>
                                        <input type="text" class="form-control numeric"  value="<?php echo $data[0]->phone;?>"  name="phone" id="phone" required>
                                    </div>
                                    
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Secondary phone</span>
                                        </div>
                                        <input type="text" class="form-control numeric" name="sec_phone" id="sec_phone" value="<?php echo $data[0]->sec_phone;?>">
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Address</span>
                                        </div>
                                        <input type="text" class="form-control" value="<?php echo $data[0]->address;?>" name="address" id="address" required>
                                    </div>
                                    
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Postcode</span>
                                        </div>
                                        <input type="text" class="form-control" value="<?php echo $data[0]->postcode;?>" name="postcode" id="postcode" required>
                                    </div>
                                   
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">NI Number</span>
                                        </div>
                                        <input type="text" class="form-control numeric" value="<?php echo $data[0]->ninumber;?>"  name="ninumber" id="ninumber" required>
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Email address</span>
                                        </div>
                                        <input type="email" class="form-control"  value="<?php echo $data[0]->email;?>" name="email" id="email" required>
                                    </div>
                                    
                                </td>

                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th colspan="2" style="background-color: #ddd;">
                                    <b>2.DETAILS OF MY PPI PAYOUTS
                        </b>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name of Financial Organisation / Bank </th>
                                        <th>Date Of PPI Pay Out <br> Month / Year </th>
                                        <th>PPI Interest Recieved</th>
                                        <th>Statements Attached</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation1;?>" name="organisation1" id="organisation1" >
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation1_date;?>" name="organisation1_date" id="organisation1_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" value="<?php echo $data[0]->organisation1_ppiinterest;?>" name="organisation1_ppiinterest" id="organisation1_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio" name="organisation1_statementattach" id="organisation1_statementattach" value="<?php echo $data[0]->organisation1_statementattach;?>" <?php echo ($data[0]->organisation1_statementattach== 1)?'checked':'' ?>>
                                            <span>No</span> <input type="radio" name="organisation1_statementattach" id="organisation1_statementattach" value="<?php echo $data[0]->organisation1_statementattach;?>" <?php echo ($data[0]->organisation1_statementattach== 0)?'checked':'' ?>>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation2;?>" name="organisation2" id="organisation2">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation2_date;?>" name="organisation2_date" id="organisation2_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" value="<?php echo $data[0]->organisation2_ppiinterest;?>" name="organisation2_ppiinterest" id="organisation2_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio"   name="organisation2_statementattach" id="organisation2_statementattach" value="<?php echo $data[0]->organisation2_statementattach;?>" <?php echo ($data[0]->organisation2_statementattach== 1)?'checked':'' ?>>
                                            <span>No</span> <input type="radio"  name="organisation2_statementattach" id="organisation2_statementattach" value="<?php echo $data[0]->organisation2_statementattach;?>" <?php echo ($data[0]->organisation2_statementattach== 0)?'checked':'' ?>>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation3;?>" name="organisation3" id="organisation3">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation3_date;?>"  name="organisation3_date" id="organisation3_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" value="<?php echo $data[0]->organisation3_ppiinterest;?>" name="organisation3_ppiinterest" id="organisation3_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio"  name="organisation3_statementattach" id="organisation3_statementattach" value="<?php echo $data[0]->organisation3_statementattach;?>" <?php echo ($data[0]->organisation3_statementattach== 1)?'checked':'' ?>>
                                            <span>No</span> <input type="radio" name="organisation3_statementattach" id="organisation3_statementattach" value="<?php echo $data[0]->organisation3_statementattach;?>" <?php echo ($data[0]->organisation3_statementattach== 0)?'checked':'' ?>>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation4;?>" name="organisation4" id="organisation4">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="<?php echo $data[0]->organisation4_date;?>" name="organisation4_date" id="organisation4_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" value="<?php echo $data[0]->organisation4_ppiinterest;?>" name="organisation4_ppiinterest" id="organisation4_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio" name="organisation4_statementattach" id="organisation4_statementattach" value="<?php echo $data[0]->organisation4_statementattach;?>" <?php echo ($data[0]->organisation4_statementattach== 1)?'checked':'' ?>>
                                            <span>No</span> <input type="radio"name="organisation4_statementattach" id="organisation4_statementattach" value="<?php echo $data[0]->organisation4_statementattach;?>" <?php echo ($data[0]->organisation4_statementattach== 0)?'checked':'' ?>>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>



                        </tbody>
                    </table>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="background-color: #ddd;">

                                </th>
                                <th>
                                    2016/2017
                                </th>
                                <th>
                                    2017/2018
                                </th>
                                <th>
                                    2018/2019
                                </th>
                                <th>
                                    2019/2020
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tbody>
                                <tr>
                                    <td>Gross Taxable Income
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year1_known" id="gross_table_income_year1_known" <?php echo ($data[0]->gross_known== 1)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[0]->gross_table_income;?>" name="gross_table_income_year1" id="gross_table_income_year1">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year2_known" id="gross_table_income_year2_known" <?php echo ($data[1]->gross_known== 1)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[1]->gross_table_income;?>" name="gross_table_income_year2" id="gross_table_income_year2">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year3_known" id="gross_table_income_year3_known" <?php echo ($data[2]->gross_known== 1)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[2]->gross_table_income;?>" name="gross_table_income_year3" id="gross_table_income_year3">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year4_known" id="gross_table_income_year4_known" <?php echo ($data[3]->gross_known== 1)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[3]->gross_table_income;?>" name="gross_table_income_year4" id="gross_table_income_year4">
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <td>Bank/Savings Interest Received
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox"  <?php echo ($data[0]->bankinterst_known== 1)?'checked':'' ?>>
                                        <span> Don't Know</span> <input type="checkbox"  <?php echo ($data[0]->bankinterst_known== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[0]->banksaving_interst_received;?>" name="interst_received_year1" id="interst_received_year1">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[1]->bankinterst_known== 1)?'checked':'' ?>>
                                        <span> Don't Know</span> <input type="checkbox" <?php echo ($data[1]->bankinterst_known== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[1]->banksaving_interst_received;?>" name="interst_received_year2" id="interst_received_year2">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[2]->bankinterst_known== 1)?'checked':'' ?>>
                                        <span>  Don't Know</span> <input type="checkbox" <?php echo ($data[2]->bankinterst_known== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric"  value="<?php echo $data[2]->banksaving_interst_received;?>" name="interst_received_year3" id="interst_received_year3">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[2]->bankinterst_known== 1)?'checked':'' ?>>
                                        <span>  Don't Know</span> <input type="checkbox" <?php echo ($data[2]->bankinterst_known== 1)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[3]->banksaving_interst_received;?>" name="interst_received_year4" id="interst_received_year4">
                                        </div>
                                    </td>


                                </tr>
                                <tr>
                                    <td>Other Interest excluding PPI

                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[0]->other_ppi== 1)?'checked':'' ?>>
                                        <span> Don't Know</span> <input type="checkbox"<?php echo ($data[0]->other_ppi== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" value="<?php echo $data[0]->other_interst_ppi;?>"  class="form-control numeric"  name="other_interst_ppi_year1" id="other_interst_ppi_year1">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox"  <?php echo ($data[1]->other_ppi== 1)?'checked':'' ?>>
                                        <span> Don't Know</span> <input type="checkbox"  <?php echo ($data[1]->other_ppi== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[1]->other_interst_ppi;?>" name="other_interst_ppi_year2" id="other_interst_ppi_year2">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[2]->other_ppi== 1)?'checked':'' ?>>
                                        <span>  Don't Know</span> <input type="checkbox" <?php echo ($data[2]->other_ppi== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[2]->other_interst_ppi;?>" name="other_interst_ppi_year3" id="other_interst_ppi_year3">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" <?php echo ($data[3]->other_ppi== 1)?'checked':'' ?>>
                                        <span>  Don't Know</span> <input type="checkbox" <?php echo ($data[3]->other_ppi== 0)?'checked':'' ?>><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" value="<?php echo $data[3]->other_interst_ppi;?>" name="other_interst_ppi_year4" id="other_interst_ppi_year4">
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </tbody>
                    </table>
                </div>
                <div class="instuction">
                    <div class="row">
                        <div class="col-lg-6">
                            <h5>What you need to do </h5>
                            <p>
                                1. Please complete this page to the best of your ability (the more information we have the faster and larger your refund will be).
                            </p>
                            <p>
                                2. Sign Forms 2 where there is an X next to the box.
                            </p>
                            <p>
                                3. Please include any ppi pay out statements you have received don’t worry if you don’t still have them.
                            </p>
                            <p>
                                4. Return the forms to: Freepost RTSZ-HJLS-GGKB , Tax Rebate Processing , St James House, Moody Street, Congleton, Cheshire CW12 4AP.
                            </p>
                        </div>
                        <div class="col-lg-6">
                            <h5>What will happen next
                            </h5>
                            <p>
                                Once your forms are received we will liaise with the Inland Revenue (HMRC) to determine your entitlements. This will be checked to make sure you receive the maximum genuine rebates.

                            </p>
                            <p>
                                Once confirmed your rebate will be sent to you via cheque. This process will then be repeated after 5th April for each year. Tax Rebate processing will retain 40% excluding VAT for processing and administration. Terms & Conditions at www.taxrebate.co.uk\terms.pdf
                            </p>
                        </div>
                    </div>
                </div><br>
                <div class="row">
               <div class="col-lg-8">
               <img src="<?php echo base_url();?>assets/images/logo/2.png" alt="logo" />
                   <div class="userdetail">
                
                       <div class="userfiel">
                        <span>Enter Name :</span> <?php echo $data[0]->fullname;?>
                       </div>
                       <div class="userfiel">
                        <span>Enter Address :</span> <?php echo $data[0]->address;?>
                       </div>
                       <div class="userfiel">
                        <span></span>
                       </div>
                       <div class="userfiel">
                        <span></span>
                       </div>
                   </div><br>
                   <div class="form-group">
                    <div class="input-group">
                          
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">NI</span>
                          </div>
                       <input type="text" class="form-control">
                    </div>
                   </div>
               </div>
               <div class="col-lg-4 text-center">
                   <h5>TAX REBATE PROCESSING</h5>
                   <div class="number">
                        <span>*1245677*</span>
                   </div>
                   <span>FORM 2</span>
               </div>
            </div>
           
         <div class="mydetails">
         <table class="table table-bordered">
<tbody>
    <tr>
        <td style="background-color: #ddd;">Dear HM Revenue and Customs</td>
    </tr>
    <tr>
        <td>
            <p>
                I would like to request a reconciliation of my tax record for the tax years entered in the box below and in the instance of refund being due i request a refund for any overpayment of tax
            </p>
            <p>
                Please refer to the details below in relation to my tax code review, together with my details of tax paid on interest from ppi redress received.

            </p>
            <p>
                I also confirm that i have not received, any foreign income or any additional pension income, or land and property income, or any trust settlement or estate income for any of the tax year ending below.

            </p>
            <p>
                I additionally request an immediate tax refund for any overpaid tax rather than receiving an adjustment to my tax code. If you require any further information please contact my agent Tax Rebate Processing.

            </p>
        </td>
    </tr>
    <tr>
        <td style="background-color: #ddd;">TAX YEARS ENDING:
        </td>
    </tr>
    <tr>
        <td style="vertical-align: middle;text-align: center;">
           <p>05/04/2018,  05/04/2019 ,  05/04/2020,  05/04/2021</p>
           
        </td>
    </tr>
    <tr>
        <td style="background-color: #ddd;">AUTHORITY (64-8)  - INDIVIDUAL TAX AFFAIRS
        </td>
    </tr>
    <tr>
        <td>
            <p>
                I agree that the nominated agent has agreed to act on my/our behalf for individual tax affairs, and the information is correct and complete. HMRC is authorised to query and disclose information with my agent
            </p>
           
        </td>
    </tr>
    <tr>
        <td>
           <div class="row" style="padding: 10px;">
               <div class="col-lg-6">
                   <i>I unconditionally assign my repayment of tax to:
                </i>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Tax Rebate Processing</td>
                        </tr>
                       
                    </tbody>
                </table>
                <i>of (full address)
                </i>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td><?php echo $data[0]->fullname;?></td>
                        </tr>
                        <tr>
                            <td>Moody Street </td>
                        </tr>
                        <tr>
                            <td>Congleton </td>
                        </tr>
                        <tr>
                            <td>Cheshire CW12 4AP</td>
                        </tr>
                    </tbody>
                </table>
                <i>
                    HMRC has not seen or endorsed this contract. </i>
                    <p><b>Date :</b> 06/04/2020</p>
               </div>
               <div class="col-lg-6" style="top: 273px;text-align: right;">
                   <div class="form-group">
                       <label>Claimant’s signature
                    </label><br>
                    <input type="text">
                   </div>
               </div>
           </div>
           
        </td>
    </tr>
   
</tbody>
         </table>
        </div>
            </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>

      

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="<?php echo base_url();?>assets/jquery/main.js"></script>


    <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/init/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
      } );
  </script>


</body>
</html>
