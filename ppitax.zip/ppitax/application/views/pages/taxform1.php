

<html>
<title>PPITAXBACK</title>
<link rel="apple-touch-icon" href="<?php echo base_url();?>assets/images/logo/1.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/1.png">
<head>
    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen" type="text/css"/>
    <link href="<?php echo base_url();?>assets/bootstrap/css/style.css" rel="stylesheet" media="screen" type="text/css" />
</head>

<body style="background-color: #ddd;">
<!-- <?php print_r($data->id);?> -->

    <div class="container">
        <div class="card">
       
            <form  action ="<?php echo 'addformdata'?>" method="POST" id="taxformuserdata">
            <input type="hidden" name='u_id' value="<?php echo $data->id?>" />
                <div class="row"> 
                    <div class="col-lg-8">
                        <img src="<?php echo base_url();?>assets/images/logo/2.png" alt="logo" />
                        <div class="userdetail">
                            <div class="userfiel">
                                <span>Enter Name : </span> <?php echo $data->name;?>
                            </div>
                            <div class="userfiel">
                                <span>Enter Address</span>
                            </div>
                            <div class="userfiel">
                                <span></span>
                            </div>
                            <div class="userfiel">
                                <span></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center">
                        <h5>TAX REBATE PROCESSING</h5>
                        <div class="number">
                            <span>*1245677*</span>
                        </div>
                        <span>FORM 1</span>
                    </div>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th colspan="2" style="background-color: #ddd;">
                                    <b>1.MY DETAILS</b>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Full Name</span>
                                        </div>
                                        <input type="text" class="form-control alpha" value="<?php echo $data->name;?>" name="fullname" id="fullname" required>
                                    </div>
                                    
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">D.O.B</span>
                                        </div>
                                        <input type="date" class="form-control"  name="dob" id="dob" required>
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Primary phone</span>
                                        </div>
                                        <input type="text" class="form-control numeric"  value="<?php echo $data->phone;?>"  name="phone" id="phone" required>
                                    </div>
                                    
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Secondary phone</span>
                                        </div>
                                        <input type="text" class="form-control numeric" name="sec_phone" id="sec_phone">
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Address</span>
                                        </div>
                                        <input type="text" class="form-control"  name="address" id="address" required>
                                    </div>
                                    
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Postcode</span>
                                        </div>
                                        <input type="text" class="form-control" name="postcode" id="postcode" required>
                                    </div>
                                   
                                </td>
                                <td>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">NI Number</span>
                                        </div>
                                        <input type="text" class="form-control numeric"  name="ninumber" id="ninumber" required>
                                    </div>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Email address</span>
                                        </div>
                                        <input type="email" class="form-control"  value="<?php echo $data->email;?>" name="email" id="email" required>
                                    </div>
                                    
                                </td>

                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th colspan="2" style="background-color: #ddd;">
                                    <b>2.DETAILS OF MY PPI PAYOUTS
                        </b>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name of Financial Organisation / Bank </th>
                                        <th>Date Of PPI Pay Out <br> Month / Year </th>
                                        <th>PPI Interest Recieved</th>
                                        <th>Statements Attached</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation1" id="organisation1" >
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation1_date" id="organisation1_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric"  name="organisation1_ppiinterest" id="organisation1_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio" name="organisation1_statementattach" id="organisation1_statementattach" value="1">
                                            <span>No</span> <input type="radio" name="organisation1_statementattach" id="organisation1_statementattach" value="0">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control"  name="organisation2" id="organisation2">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation2_date" id="organisation2_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" name="organisation2_ppiinterest" id="organisation2_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio"  name="organisation2_statementattach" id="organisation2_statementattach" value="1">
                                            <span>No</span> <input type="radio"  name="organisation2_statementattach" id="organisation2_statementattach" value="0">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation3" id="organisation3">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation3_date" id="organisation3_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" name="organisation3_ppiinterest" id="organisation3_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio"  name="organisation3_statementattach" id="organisation3_statementattach" value="1">
                                            <span>No</span> <input type="radio" name="organisation3_statementattach" id="organisation3_statementattach" value="0">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control"  name="organisation4" id="organisation4">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="organisation4_date" id="organisation4_date">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="input-group">

                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">&#163;</span>
                                                </div>
                                                <input type="text" class="form-control numeric" name="organisation4_ppiinterest" id="organisation4_ppiinterest">
                                            </div>
                                        </td>
                                        <td>
                                            <span>Yes</span> <input type="radio" name="organisation4_statementattach" id="organisation4_statementattach" value="1">
                                            <span>No</span> <input type="radio"name="organisation4_statementattach" id="organisation4_statementattach" value="0">
                                        </td>
                                    </tr>

                                </tbody>
                            </table>



                        </tbody>
                    </table>
                </div>
                <div class="mydetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="background-color: #ddd;">

                                </th>
                                <th>
                                    2016/2017
                                </th>
                                <th>
                                    2017/2018
                                </th>
                                <th>
                                    2018/2019
                                </th>
                                <th>
                                    2019/2020
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tbody>
                                <tr>
                                    <td>Gross Taxable Income
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year1_known" id="gross_table_income_year1_known" value="1"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="gross_table_income_year1" id="gross_table_income_year1">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year2_known" id="gross_table_income_year2_known"  value="1"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="gross_table_income_year2" id="gross_table_income_year2">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year3_known" id="gross_table_income_year3_known"  value="1"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="gross_table_income_year3" id="gross_table_income_year3">
                                        </div>
                                    </td>
                                    <td>
                                        Don't Know <input type="checkbox" name="gross_table_income_year4_known" id="gross_table_income_year4_known"  value="1"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="gross_table_income_year4" id="gross_table_income_year4">
                                        </div>
                                    </td>

                                </tr>
                                <tr>
                                    <td>Bank/Savings Interest Received
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox"  name="interst_received_year1_none" id="interst_received_year1_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox"  name="interst_received_year1_no" id="interst_received_year1_no" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="interst_received_year1" id="interst_received_year1">
                                        </div>
                                    </td>
                                    <td>
                                        <span> None </span><input type="checkbox" name="interst_received_year2_none" id="interst_received_year2_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox" name="interst_received_year2_none" id="interst_received_year2_none" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="interst_received_year2" id="interst_received_year2">
                                        </div>
                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox" name="interst_received_year3_none" id="interst_received_year3_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox" name="interst_received_year3_none" id="interst_received_year3_none" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="interst_received_year3" id="interst_received_year3">
                                        </div>
                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox" name="interst_received_year4_none" id="interst_received_year4_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox" name="interst_received_year4_none" id="interst_received_year4_none" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="interst_received_year4" id="interst_received_year4">
                                        </div>
                                    </td>


                                </tr>
                                <tr>
                                    <td>Other Interest excluding PPI

                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox"  name="other_interst_ppi_year1_none" id="other_interst_ppi_year1_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox"  name="other_interst_ppi_year1_none" id="other_interst_ppi_year1_no" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric"  name="other_interst_ppi_year1" id="other_interst_ppi_year1">
                                        </div>
                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox"  name="other_interst_ppi_year2_none" id="other_interst_ppi_year2_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox"  name="other_interst_ppi_year2_none" id="other_interst_ppi_year2_no" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="other_interst_ppi_year2" id="other_interst_ppi_year2">
                                        </div>
                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox"  name="other_interst_ppi_year3_none" id="other_interst_ppi_year3_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox"  name="other_interst_ppi_year3_none" id="other_interst_ppi_year3_no" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="other_interst_ppi_year3" id="other_interst_ppi_year3">
                                        </div>
                                    </td>
                                    <td>
                                    <span> None </span><input type="checkbox"  name="other_interst_ppi_year4_none" id="other_interst_ppi_year4_none" value="1">
                                        <span> Don't Know</span> <input type="checkbox"  name="other_interst_ppi_year4_none" id="other_interst_ppi_year4_no" value="0"><br>
                                        <div class="input-group">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1">&#163;</span>
                                            </div>
                                            <input type="text" class="form-control numeric" name="other_interst_ppi_year4" id="other_interst_ppi_year4">
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </tbody>
                    </table>
                </div>
                <div class="instuction">
                    <div class="row">
                        <div class="col-lg-6">
                            <h5>What you need to do </h5>
                            <p>
                                1. Please complete this page to the best of your ability (the more information we have the faster and larger your refund will be).
                            </p>
                            <p>
                                2. Sign Forms 2 where there is an X next to the box.
                            </p>
                            <p>
                                3. Please include any ppi pay out statements you have received don’t worry if you don’t still have them.
                            </p>
                            <p>
                                4. Return the forms to: Freepost RTSZ-HJLS-GGKB , Tax Rebate Processing , St James House, Moody Street, Congleton, Cheshire CW12 4AP.
                            </p>
                        </div>
                        <div class="col-lg-6">
                            <h5>What will happen next
                            </h5>
                            <p>
                                Once your forms are received we will liaise with the Inland Revenue (HMRC) to determine your entitlements. This will be checked to make sure you receive the maximum genuine rebates.

                            </p>
                            <p>
                                Once confirmed your rebate will be sent to you via cheque. This process will then be repeated after 5th April for each year. Tax Rebate processing will retain 40% excluding VAT for processing and administration. Terms & Conditions at www.taxrebate.co.uk\terms.pdf
                            </p>
                        </div>
                    </div>
                </div><br>
                <div class="row">
               <div class="col-lg-8">
                   <div class="userdetail">
                       <div class="userfiel">
                        <span>Enter Name</span> <?php echo $data->name;?>
                       </div>
                       <div class="userfiel">
                        <span>Enter Address</span>
                       </div>
                       <div class="userfiel">
                        <span></span>
                       </div>
                       <div class="userfiel">
                        <span></span>
                       </div>
                   </div><br>
                   <div class="form-group">
                    <div class="input-group">
                          
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">NI</span>
                          </div>
                       <input type="text" class="form-control">
                    </div>
                   </div>
               </div>
               <div class="col-lg-4 text-center">
                   <h5>TAX REBATE PROCESSING</h5>
                   <div class="number">
                        <span>*1245677*</span>
                   </div>
                   <span>FORM 2</span>
               </div>
            </div>
           
         <div class="mydetails">
         <table class="table table-bordered">
<tbody>
    <tr>
        <td style="background-color: #ddd;">Dear HM Revenue and Customs</td>
    </tr>
    <tr>
        <td>
            <p>
                I would like to request a reconciliation of my tax record for the tax years entered in the box below and in the instance of refund being due i request a refund for any overpayment of tax
            </p>
            <p>
                Please refer to the details below in relation to my tax code review, together with my details of tax paid on interest from ppi redress received.

            </p>
            <p>
                I also confirm that i have not received, any foreign income or any additional pension income, or land and property income, or any trust settlement or estate income for any of the tax year ending below.

            </p>
            <p>
                I additionally request an immediate tax refund for any overpaid tax rather than receiving an adjustment to my tax code. If you require any further information please contact my agent Tax Rebate Processing.

            </p>
        </td>
    </tr>
    <tr>
        <td style="background-color: #ddd;">TAX YEARS ENDING:
        </td>
    </tr>
    <tr>
        <td style="vertical-align: middle;text-align: center;">
           <p>05/04/2018,  05/04/2019 ,  05/04/2020,  05/04/2021</p>
           
        </td>
    </tr>
    <tr>
        <td style="background-color: #ddd;">AUTHORITY (64-8)  - INDIVIDUAL TAX AFFAIRS
        </td>
    </tr>
    <tr>
        <td>
            <p>
                I agree that the nominated agent has agreed to act on my/our behalf for individual tax affairs, and the information is correct and complete. HMRC is authorised to query and disclose information with my agent
            </p>
           
        </td>
    </tr>
    <tr>
        <td>
           <div class="row" style="padding: 10px;">
               <div class="col-lg-6">
                   <i>I unconditionally assign my repayment of tax to:
                </i>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Tax Rebate Processing</td>
                        </tr>
                       
                    </tbody>
                </table>
                <i>of (full address)
                </i>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td><?php echo $data->name;?></td>
                        </tr>
                        <tr>
                            <td>Moody Street </td>
                        </tr>
                        <tr>
                            <td>Congleton </td>
                        </tr>
                        <tr>
                            <td>Cheshire CW12 4AP</td>
                        </tr>
                    </tbody>
                </table>
                <i>
                    HMRC has not seen or endorsed this contract. </i>
                    <p><b>Date :</b> 06/04/2020</p>
               </div>
               <div class="col-lg-6" style="top: 273px;text-align: right;">
                   <div class="form-group">
                       <label>Claimant’s signature
                    </label><br>
                    <input type="text">
                   </div>
               </div>
           </div>
           
        </td>
    </tr>
   
</tbody>
         </table>
        </div><br>
                <div class="row">
                    <divv class="col-lg-12 text-center">
                        <div class="form-group">
                            <button type="submit" class="btn btn-info">Finish</button>
                        </div>
                    </divv>
                </div>
            </form>
        </div>
    </div>
    <script async src="<?php echo base_url('assets/jquery/jquery-3.1.1.min.js');?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/jquery/logout.js')?>"></script>
</body>

</html>