<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Mirrored from www.digitalfsg.com/ppitaxback/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Apr 2020 12:21:38 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->

<head>
    <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--fade6928-d836-4376-86b5-ffee4a14d8a9 a-->

    <title>PPITACBACK</title>
    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/images/logo/1.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/logo/1.png">
    <meta name="keywords" content="">
    <meta name="description" content="">

	<style title="page-styles" type="text/css" data-page-type="main_desktop">
	body {
 color:#666;
}
a {
 color:#36b3a8;
 text-decoration:none;
}
#lp-pom-image-380 {
 left:472px;
 top:2px;
 display:block;
 background:rgba(255,255,255,0);
 z-index:10;
 position:absolute;
}
#lp-pom-text-382 {
 left:572px;
 top:216.5px;
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 z-index:1;
 width:526px;
 height:232px;
 position:absolute;
}
#lp-pom-box-396 {
 left:0px;
 top:188px;
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 border-radius:0px;
 z-index:4;
 width:545px;
 height:490px;
 position:absolute;
}
#lp-pom-text-424 {
 left:315.5px;
 top:1654.666748046875px;
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 z-index:2;
 width:569px;
 height:22px;
 position:absolute;
}
#lp-pom-text-427 {
 left:198px;
 top:1792px;
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 z-index:3;
 width:310px;
 height:44px;
 position:absolute;
}
#lp-pom-root {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 margin:auto;
 padding-top:0px;
 border-radius:0px;
 min-width:1200px;
 height:1726px;
}
#lp-pom-block-376 {
 display:block;
 background:rgba(255,255,255,0.2);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:1200px;
 height:121px;
 position:relative;
}
#lp-pom-block-381 {
 display:block;
 background:rgba(228,241,253,0.2);
 background-image:url(<?php echo base_url('assets/images/img/bg.jpg');?>);
 background-attachment:fixed;
 background-repeat:no-repeat;
 background-position:center top;
 background-size:cover;
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:428px;
 position:relative;
}
#lp-pom-text-399 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:30px;
 top:40px;
 z-index:7;
 width:288px;
 height:25px;
 position:absolute;
}
#lp-pom-text-458 {
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:54px;
 top:17px;
 z-index:8;
 width:300px;
 height:34px;
 position:absolute;
}
#lp-pom-block-392 {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none none none none;
 border-width:undefinedpx;
 border-color:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:61px;
 border-radius:0px;
 width:100%;
 height:998px;
 position:relative;
}
#lp-pom-box-449 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:solid;
 border-width:1px;
 border-color:#000000;
 border-radius:0px;
 left:800px;
 top:672px;
 z-index:14;
 width:398px;
 height:874px;
 position:absolute;
}
#lp-pom-text-448 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:24px;
 top:31px;
 z-index:15;
 width:360px;
 height:676px;
 position:absolute;
}
#lp-pom-text-450 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:0px;
 top:709px;
 z-index:11;
 width:300px;
 height:25px;
 position:absolute;
}
#lp-pom-text-451 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:0px;
 top:760px;
 z-index:9;
 width:771px;
 height:490px;
 position:absolute;
}
#lp-pom-image-454 {
 display:block;
 background:rgba(255,255,255,0);
 left:0px;
 top:1285px;
 z-index:12;
 position:absolute;
}
#lp-pom-image-455 {
 display:block;
 background:rgba(255,255,255,0);
 left:427px;
 top:1285px;
 z-index:13;
 position:absolute;
}
#lp-pom-button-398 {
 display:block;
 border-style:none;
 border-radius:3px;
 left:0px;
 top:296px;
 z-index:6;
 width:476px;
 height:57px;
 position:absolute;
 background:rgba(0,0,0,1);
 box-shadow:none;
 text-shadow:none;
 color:#fff;
 border-width:undefinedpx;
 border-color:#undefined;
 font-size:17px;
 line-height:20px;
 font-weight:400;
 font-family:Roboto;
 font-style:normal;
 text-align:center;
 background-repeat:no-repeat;
}
#lp-pom-block-423 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:118px;
 position:relative;
}
#lp-pom-root .lp-positioned-content {
 top:0px;
 width:1200px;
 margin-left:-600px;
}
#lp-pom-block-376 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:121px;
}
#lp-pom-block-381 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:428px;
}
#lp-pom-block-392 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:998px;
}
#lp-pom-image-380 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:256px;
 height:117px;
}
#lp-pom-image-380 .lp-pom-image-container img {
 width:256px;
 height:117px;
}
#container_name {
 position:absolute;
 top:0px;
 left:0px;
 width:476px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_name {
 position:absolute;
 top:22px;
 left:0px;
 width:476px;
 height:52px;
}
#label_name {
 position:absolute;
 top:0px;
 left:0px;
 width:476px;
 height:18px;
}
#container_phone {
 position:absolute;
 top:94px;
 left:0px;
 width:476px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_phone {
 position:absolute;
 top:22px;
 left:0px;
 width:476px;
 height:52px;
}
#label_phone {
 position:absolute;
 top:0px;
 left:0px;
 width:476px;
 height:18px;
}
#container_email {
 position:absolute;
 top:188px;
 left:0px;
 width:476px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_email {
 position:absolute;
 top:22px;
 left:0px;
 width:476px;
 height:52px;
}
#label_email {
 position:absolute;
 top:0px;
 left:0px;
 width:476px;
 height:18px;
}
#lp-pom-button-398:hover {
 background:rgba(0,0,0,1);
 box-shadow:none;
 color:#fff;
}
#lp-pom-button-398:active {
 background:rgba(0,0,0,1);
 box-shadow:none;
 color:#fff;
}
#lp-pom-button-398 .label {
 margin-top:-10px;
}
#lp-pom-block-423 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:1200px;
 height:118px;
}
#lp-pom-image-454 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:345px;
 height:262px;
}
#lp-pom-image-454 .lp-pom-image-container img {
 width:345px;
 height:262px;
}
#lp-pom-image-455 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:345px;
 height:262px;
}
#lp-pom-image-455 .lp-pom-image-container img {
 width:345px;
 height:262px;
}
#lp-pom-root-color-overlay {
 position:absolute;
 background:none;
 top:0;
 width:100%;
 height:1726px;
 min-height:100%;
}
#lp-pom-block-376-color-overlay {
 position:absolute;
 background:none;
 height:121px;
 width:1200px;
}
#lp-pom-block-381-color-overlay {
 position:absolute;
 background:rgba(228,241,253,0.2);
 height:428px;
 width:100%;;
}
#lp-pom-block-392-color-overlay {
 position:absolute;
 background:none;
 height:998px;
 width:100%;;
}
#lp-pom-box-396-color-overlay {
 position:absolute;
 background:none;
 height:490px;
 width:545px;
}
#lp-pom-block-423-color-overlay {
 position:absolute;
 background:none;
 height:118px;
 width:100%;;
}
#lp-pom-box-449-color-overlay {
 position:absolute;
 background:none;
 height:874px;
 width:398px;
}
#lp-pom-form-397 {
 display:block;
 left:34px;
 top:100px;
 z-index:5;
 width:476px;
 height:0px;
 position:absolute;
}
#lp-pom-form-397 .fields {
 margin:-10px;
}
#lp-pom-form-397 .lp-pom-form-field {
 position:absolute;
}
#lp-pom-form-397 .option {
 position:absolute;
}
#lp-pom-form-397 .optionsList {
 position:absolute;
}
#lp-pom-form-397 .lp-pom-form-field .single {
 height:52px;
 font-size:15px;
 line-height:15px;
 padding-left:16px;
 padding-right:16px;
 flex:1;
}
#lp-pom-form-397 .lp-pom-form-field select {
 height:48px;
}
#lp-pom-form-397 .lp-pom-form-field .form_elem_multi {
 padding-top:16px;
 padding-bottom:17px;
}
#lp-pom-form-397 .lp-pom-form-field .lp-form-label {
 font-family:PT Sans;
 font-weight:400;
 font-size:16px;
 line-height:18px;
 color:#000000;
 display:block;
 margin-bottom:4px;
 width:auto;
 margin-right:0px;
}
#lp-pom-form-397 .lp-pom-form-field .lp-form-label .label-style {
 font-weight:bolder;
 font-style:inherit;
}
#lp-pom-form-397 .lp-pom-form-field input[type=text], #lp-pom-form-397 .lp-pom-form-field input[type=email], #lp-pom-form-397 .lp-pom-form-field input[type=tel], #lp-pom-form-397 .lp-pom-form-field textarea, #lp-pom-form-397 .lp-pom-form-field select {
 border-style:solid;
 border-width:2px;
 border-color:#919191;
}
#lp-pom-form-397 .lp-pom-form-field .opt-label {
 font-family:arial;
 font-weight:400;
 font-size:15px;
 color:#000;
 line-height:17px;
}
#lp-pom-form-397 .lp-pom-form-field .opt-label .label-style {
 font-weight:inherit;
 font-style:inherit;
}
#lp-pom-form-397 .lp-pom-form-field .text {
 background-color:#fff;
 color:#000000;
}
</style>
<style title="page-styles" type="text/css" data-page-type="main_mobile">
@media only screen and (max-width: 600px) {
#lp-pom-root {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 margin:auto;
 padding-top:0px;
 border-radius:0px;
 min-width:320px;
 height:3283px;
}
#lp-pom-block-376 {
 display:block;
 background:rgba(255,255,255,0.2);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:320px;
 height:111px;
 position:relative;
}
#lp-pom-image-380 {
 display:block;
 background:rgba(255,255,255,0);
 left:43px;
 top:1px;
 z-index:10;
 position:absolute;
}
#lp-pom-block-381 {
 display:block;
 background:rgba(228,241,253,0.2);
 background-image:url(<?php echo base_url('assets/images/img/bg.jpg');?>);
 background-repeat:no-repeat;
 background-position:left top;
 background-size:cover;
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:399px;
 position:relative;
}
#lp-pom-text-382 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:20px;
 top:141px;
 z-index:1;
 width:334px;
 height:348px;
 transform:scale(0.8383233532934131);
 transform-origin:0 0;
 -webkit-transform:scale(0.8383233532934131);
 -webkit-transform-origin:0 0;
 position:absolute;
}
#lp-pom-box-396 {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none;
 border-radius:0px;
 left:0px;
 top:452px;
 z-index:4;
 width:320px;
 height:426px;
 position:absolute;
}
#lp-pom-text-399 {
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:16px;
 top:25px;
 z-index:7;
 width:234px;
 height:50px;
 position:absolute;
}
#lp-pom-text-458 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:16px;
 top:10px;
 z-index:8;
 width:300px;
 height:34px;
 position:absolute;
}
#lp-pom-block-392 {
 display:block;
 background:rgba(255,255,255,1);
 border-style:none none none none;
 border-width:undefinedpx;
 border-color:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:1970px;
 border-radius:0px;
 width:100%;
 height:666px;
 position:relative;
}
#lp-pom-box-449 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:solid;
 border-width:1px;
 border-color:#000000;
 border-radius:0px;
 left:0px;
 top:2289px;
 z-index:14;
 width:319px;
 height:836px;
 position:absolute;
}
#lp-pom-text-448 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:15px;
 top:23px;
 z-index:15;
 width:288px;
 height:792px;
 position:absolute;
}
#lp-pom-text-450 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:9px;
 top:883px;
 z-index:11;
 width:300px;
 height:25px;
 transform:scale(1.05);
 transform-origin:0 0;
 -webkit-transform:scale(1.05);
 -webkit-transform-origin:0 0;
 position:absolute;
}
#lp-pom-text-451 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:9px;
 top:922px;
 z-index:9;
 width:301px;
 height:820px;
 position:absolute;
}
#lp-pom-image-454 {
 display:block;
 background:rgba(255,255,255,0);
 left:0px;
 top:1766px;
 z-index:12;
 position:absolute;
}
#lp-pom-image-455 {
 display:block;
 background:rgba(255,255,255,0);
 left:0px;
 top:2026px;
 z-index:13;
 position:absolute;
}
#lp-pom-button-398 {
 display:block;
 border-style:none;
 border-radius:3px;
 left:0px;
 top:283px;
 z-index:6;
 width:257px;
 height:61px;
 position:absolute;
 background:rgba(0,0,0,1);
 box-shadow:none;
 text-shadow:none;
 color:#fff;
 border-width:undefinedpx;
 border-color:#undefined;
 font-size:17px;
 line-height:20px;
 font-weight:400;
 font-family:Roboto;
 font-style:normal;
 text-align:center;
 background-repeat:no-repeat;
}
#lp-pom-text-424 {
 display:none;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:10px;
 top:3156px;
 z-index:2;
 width:284px;
 height:44px;
 position:absolute;
}
#lp-pom-text-427 {
 display:block;
 background:rgba(255,255,255,0);
 border-style:none;
 border-radius:0px;
 left:26px;
 top:3182px;
 z-index:3;
 width:252px;
 height:66px;
 position:absolute;
}
#lp-pom-block-423 {
 display:block;
 background:rgba(0,0,0,1);
 border-style:none;
 margin-left:auto;
 margin-right:auto;
 margin-bottom:0px;
 border-radius:0px;
 width:100%;
 height:137px;
 position:relative;
}
body {
 color:#666;
}
a {
 color:#36b3a8;
 text-decoration:none;
}
#lp-pom-root .lp-positioned-content {
 top:0px;
 width:320px;
 margin-left:-160px;
}
#lp-pom-block-376 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:111px;
}
#lp-pom-block-381 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:399px;
}
#lp-pom-block-392 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:666px;
}
#lp-pom-image-380 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:234px;
 height:107px;
}
#lp-pom-image-380 .lp-pom-image-container img {
 width:234px;
 height:107px;
}
#container_name {
 position:absolute;
 top:0px;
 left:0px;
 width:260px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_name {
 position:absolute;
 top:22px;
 left:0px;
 width:260px;
 height:52px;
}
#label_name {
 position:absolute;
 top:0px;
 left:0px;
 width:260px;
 height:18px;
}
#container_phone {
 position:absolute;
 top:94px;
 left:0px;
 width:260px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_phone {
 position:absolute;
 top:22px;
 left:0px;
 width:260px;
 height:52px;
}
#label_phone {
 position:absolute;
 top:0px;
 left:0px;
 width:260px;
 height:18px;
}
#container_email {
 position:absolute;
 top:188px;
 left:0px;
 width:260px;
 height:74px;
}
.lp-pom-form-field .ub-input-item.single.form_elem_email {
 position:absolute;
 top:22px;
 left:0px;
 width:260px;
 height:52px;
}
#label_email {
 position:absolute;
 top:0px;
 left:0px;
 width:260px;
 height:18px;
}
#lp-pom-button-398:hover {
 background:rgba(0,0,0,1);
 box-shadow:none;
 color:#fff;
}
#lp-pom-button-398:active {
 background:rgba(0,0,0,1);
 box-shadow:none;
 color:#fff;
}
#lp-pom-button-398 .label {
 margin-top:-10px;
}
#lp-pom-block-423 .lp-pom-block-content {
 margin-left:auto;
 margin-right:auto;
 width:320px;
 height:137px;
}
#lp-pom-image-454 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:321px;
 height:244px;
}
#lp-pom-image-454 .lp-pom-image-container img {
 width:321px;
 height:244px;
}
#lp-pom-image-455 .lp-pom-image-container {
 border-style:none;
 border-radius:0px;
 width:321px;
 height:244px;
}
#lp-pom-image-455 .lp-pom-image-container img {
 width:321px;
 height:244px;
}
#lp-pom-root-color-overlay {
 position:absolute;
 background:none;
 top:0;
 width:100%;
 height:3283px;
 min-height:100%;
}
#lp-pom-block-376-color-overlay {
 position:absolute;
 background:none;
 height:111px;
 width:320px;
}
#lp-pom-block-381-color-overlay {
 position:absolute;
 background:none;
 height:399px;
 width:100%;;
}
#lp-pom-block-392-color-overlay {
 position:absolute;
 background:none;
 height:666px;
 width:100%;;
}
#lp-pom-box-396-color-overlay {
 position:absolute;
 background:none;
 height:426px;
 width:320px;
}
#lp-pom-block-423-color-overlay {
 position:absolute;
 background:none;
 height:137px;
 width:100%;;
}
#lp-pom-box-449-color-overlay {
 position:absolute;
 background:none;
 height:836px;
 width:319px;
}
#lp-pom-form-397 {
 display:block;
 left:16px;
 top:54px;
 z-index:5;
 width:260px;
 height:0px;
 position:absolute;
}
#lp-pom-form-397 .fields {
 margin:-10px;
}
#lp-pom-form-397 .lp-pom-form-field {
 position:absolute;
}
#lp-pom-form-397 .option {
 position:absolute;
}
#lp-pom-form-397 .optionsList {
 position:absolute;
}
#lp-pom-form-397 .lp-pom-form-field .single {
 height:52px;
 font-size:15px;
 line-height:15px;
 padding-left:16px;
 padding-right:16px;
 flex:1;
}
#lp-pom-form-397 .lp-pom-form-field select {
 height:48px;
}
#lp-pom-form-397 .lp-pom-form-field .form_elem_multi {
 padding-top:16px;
 padding-bottom:17px;
}
#lp-pom-form-397 .lp-pom-form-field .lp-form-label {
 font-family:PT Sans;
 font-weight:400;
 font-size:16px;
 line-height:18px;
 color:#000000;
 display:block;
 margin-bottom:4px;
 width:auto;
 margin-right:0px;
}
#lp-pom-form-397 .lp-pom-form-field .lp-form-label .label-style {
 font-weight:bolder;
 font-style:inherit;
}
#lp-pom-form-397 .lp-pom-form-field input[type=text], #lp-pom-form-397 .lp-pom-form-field input[type=email], #lp-pom-form-397 .lp-pom-form-field input[type=tel], #lp-pom-form-397 .lp-pom-form-field textarea, #lp-pom-form-397 .lp-pom-form-field select {
 border-style:solid;
 border-width:2px;
 border-color:#919191;
}
#lp-pom-form-397 .lp-pom-form-field .opt-label {
 font-family:arial;
 font-weight:400;
 font-size:15px;
 color:#000;
 line-height:17px;
}
#lp-pom-form-397 .lp-pom-form-field .opt-label .label-style {
 font-weight:inherit;
 font-style:inherit;
}
#lp-pom-form-397 .lp-pom-form-field .text {
 background-color:#fff;
 color:#000000;
}
}
@media only screen and (max-width: 600px) and (-webkit-min-device-pixel-ratio: 1.1), only screen and (max-width: 600px) and (min-resolution: 97dpi) {
#lp-pom-block-381 {
 background-image:url(<?php echo base_url('assets/images/img/bg.jpg');?>);
}
}
@media only screen and (max-width: 600px) and (-webkit-min-device-pixel-ratio: 2.1), only screen and (max-width: 600px) and (min-resolution: 193dpi) {
#lp-pom-block-381 {
 background-image:url(<?php echo base_url('assets/images/img/bg.jpg');?>);
}
}
	</style>

    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="lp-version" content="v6.21.10">

    <!-- lp:insertions start head -->
    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen" type="text/css"/>
    <link href="<?php echo base_url();?>assets/bootstrap/css/unbounce.css" rel="stylesheet" media="screen" type="text/css" />
    <!-- <link href="<?php echo base_url();?>assets/bootstrap/css/index.css" rel="stylesheet" media="screen" type="text/css" /> -->
    <meta property='og:title' content='' />
	<script type="text/javascript">
	window.ub = {"page":
	{"id":"fade6928-d836-4376-86b5-ffee4a14d8a9",
	"variantId":"a",
	"usedAs":"main","name":"PPI TAX REBATE BACK","url":"",
	"dimensions":{"desktop":{"height":1726,"width":1200},
	"mobile":{"height":3283,"width":320},"mobileMaxWidth":600}},"hooks":{"beforeFormSubmit":[],"afterFormSubmit":[]}};</script><script>window.ub.page.webFonts = ['PT Sans:regular,700','Roboto:700,regular','Source Sans Pro:italic'];</script><script type="text/javascript">window.ub.form={"action":"modal","validationRules":{"name":{"required":true},"phone":{"required":true,"phone":true},"email":{"required":true,"email":true}},"validationMessages":{"name":{},"phone":{},"email":{}},"customValidators":{},"url":"a-form_confirmation.html","lightboxSize":{"desktop":{"height":162,"width":512},"mobile":{"height":162,"width":240}},"isConversionGoal":true};window.module={lp:{form:{data:window.ub.form}}};</script><!-- lp:insertions end head -->
</head>

<body class="lp-pom-body">
    <!-- lp:insertions start body:before -->
    <!-- lp:insertions end body:before -->

    <?php
if($error = $this->session->flashdata('error')){ ?>
      <div class="alert alert-danger"> <?php echo $error; ?> </div>
           
      <?php  }
        ?>

    <div class="lp-element lp-pom-root" id="lp-pom-root">
        <div id="lp-pom-root-color-overlay"></div>
        <div class="lp-positioned-content">
            <div class="lp-element lp-pom-image" id="lp-pom-image-380">
                <div class="lp-pom-image-container" style="overflow: hidden;">
                    <img src="<?php echo base_url();?>assets/images/logo/1.png" alt="" 
                    data-src-desktop-1x="<?php echo base_url();?>assets/images/logo/1.png" 
                    data-src-desktop-2x="<?php echo base_url();?>assets/images/logo/1.png"
                    data-src-mobile-1x="<?php echo base_url();?>assets/images/logo/1.png" 
                    data-src-mobile-2x="<?php echo base_url();?>assets/images/logo/1.png">
                </div>
            </div>
            <div class="lp-element lp-pom-text nlh" id="lp-pom-text-382">
                <h1 class="lplh-58" style="line-height: 58px;">
                    <span style="color: rgb(255, 255, 255);"><strong>
          <span style="font-family:pt sans;"><span style="font-size: 48px;">If you have received a PPI payout you may be eligible to claim tax back on it&nbsp;</span></span>
                    </strong>
                    </span>
                </h1>
            </div>
            <div class="lp-element lp-pom-box" id="lp-pom-box-396">
                <div id="lp-pom-box-396-color-overlay"></div>
                <div class="lp-element lp-pom-form has-axis" id="lp-pom-form-397">
                    <form action="<?php echo 'index.php/welcome/checkuser'?>" method="POST" id="checkuserform">
                    <input type="hidden" name="pageId" value="fade6928-d836-4376-86b5-ffee4a14d8a9">
                        <input type="hidden" name="pageVariant" value="a">
                        <div class="fields">
                            <div class="lp-pom-form-field single-line-text" id="container_name">
                                <label class="main lp-form-label" for="name" id="label_name"><span class="label-style">Name&nbsp;*</span></label><input id="name" name="name" type="text" class="ub-input-item single text form_elem_name" required=""></div>
                            <div class="lp-pom-form-field single-line-text" id="container_phone">
                                <label class="main lp-form-label" for="phone" id="label_phone"><span class="label-style">Phone&nbsp;*</span></label><input id="phone" name="phone" type="tel" class="ub-input-item single text form_elem_phone" required="" maxlength="11">
                            </div>
                            <div class="lp-pom-form-field email" id="container_email">
                                <label class="main lp-form-label" for="email" id="label_email"><span class="label-style">Email&nbsp;*</span></label>
                                <input id="email" name="email" type="email" class="ub-input-item single text form_elem_email" required="" pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9_-]+\.[a-zA-Z0-9-.]{2,61}$">
                            </div>
                        </div>
                        <input href="javascript:void(0);" name="submit" href class="lp-element lp-pom-button" id="lp-pom-button-398" type="submit" value="Submit">
                        <input type="text" id="xcXowOvMxgh7u19iqRg0fU7Vln5MwqRK" name="ubafs-xcXowOvMxgh7u19iqRg0fU7Vln5MwqRK" style="display:none !important;">
                    </form>
                </div>
                <div class="lp-element lp-pom-text nlh" id="lp-pom-text-399">
                    <h2 data-element-type="paragraph"><span style="font-size: 28px; color: rgb(0, 0, 0);">Start your claim now</span></h2>
                </div>
                <div class="lp-element lp-pom-text nlh" id="lp-pom-text-458">
                    <h1><span style="font-size: 24px; color: rgb(0, 0, 0);">Start Now!</span></h1>
                </div>
            </div>
            <div class="lp-element lp-pom-text nlh" id="lp-pom-text-424">
                <p><span style="color: rgb(255, 255, 255); font-size: 14px;">© 2020 All Rights Reserved | ppitaxback.org is a trading style of Dodl Holdings Limited. </span></p>
            </div>
            <div class="lp-element lp-pom-text nlh" id="lp-pom-text-427">
                <p style="text-align: center;"><span style="font-size: 16px; font-family: &quot;PT Sans&quot;; color: rgb(255, 255, 255);">© 2020 All Rights Reserved | ppitaxback.org is a trading style of Dodl Holdings Limited.&nbsp;</span></p>
            </div>
            <div class="lp-element lp-pom-box" id="lp-pom-box-449">
                <div id="lp-pom-box-449-color-overlay"></div>
                <div class="lp-element lp-pom-text nlh" id="lp-pom-text-448">
                    <p style="line-height: 29px;"><span style="color: rgb(255, 255, 255); font-size: 18px;">If tax is due on PPI payouts, most firms deduct it automatically, at 20 per cent, before you get the money. That has always been an issue for non-taxpayers.</span></p>
                    <p style="line-height: 29px;"><span style="font-size: 18px;"><span style="color: rgb(255, 255, 255);">However, since April 6, 2016, far more people have been owed tax back, as that’s when the personal savings allowance launched.</span></span>
                    </p>
                    <p style="line-height: 29px;"><span style="font-size: 18px;"><span style="color: rgb(255, 255, 255);">It allows most taxpayers to earn £1,000 a year of savings interest, tax-free.</span></span>
                    </p>
                    <p style="line-height: 29px;"><span style="font-size: 18px;"><span style="color: rgb(255, 255, 255);">Since then, while most savings interest has been paid without any tax taken off, PPI still has 20 per cent automatically deducted.</span></span>
                    </p>
                    <p style="line-height: 29px;"><span style="font-size: 18px;"><span style="color: rgb(255, 255, 255);">And as PPI is taxed as a lump sum at the point it is paid, most people who have been paid tax on PPI payouts since then are entitled to money back.</span></span>
                    </p>
                    <p style="line-height: 29px;"><span style="font-size: 18px;"><span style="color: rgb(255, 255, 255);">The tax can be £1,000+</span></span>
                    </p>
                    <p style="line-height: 29px;"><span style="color: rgb(255, 255, 255); font-size: 18px;">For every £100 of Statutory Interest earned, £20 is taken off in tax.</span></p>
                </div>
            </div>
            <div class="lp-element lp-pom-text nlh" id="lp-pom-text-450">
                <h2 data-element-type="paragraph" data-uialign="left"><span style="font-size: 26px;">Tax Reclaims</span></h2>
            </div>
            <div class="lp-element lp-pom-text nlh" id="lp-pom-text-451">
                <p><span style="font-size: 18px;">To be eligible you must;</span></p>
                <p><span style="font-size: 18px;">1. Have received a PPI payout in the last 4 years (Since the start of 2016)&nbsp;</span></p>
                <p><span style="font-size: 18px;">2. Be a UK resident<br></span></p>
                <p><span style="font-size: 18px;">It is much quicker and easier if you have a PPI Settlement Letter or Statement from the bank you claimed from, you can take a picture of scan this to us one your claim is sarted if you have it.</span></p>
                <p><span style="font-size: 18px;">If you don’t have one you can still apply, we will request a copy of the letter for you as part of our process.&nbsp;</span></p>
                <p><span style="font-size: 18px;">The quickest way to get your tax rebate for PPI is to enter your information above and speak to one of our Expert Advisers when they call you. A pack will be sent to you to check over and return to us by post.&nbsp;</span></p>
                <p><span style="font-size: 18px;">Did you know;<br></span></p>
                <p><span style="font-size: 18px;">- A non taxpayer could get up to 20% of their entire PPI payout for each year.&nbsp;</span></p>
                <p><span style="font-size: 18px;">- A basic rate taxpayer is entitled to £1000 of interest tax free per year.</span></p>
                <p><span style="font-size: 18px;">- A higher rate taxpayer is entitled to £500 of interest tax free per year.</span></p>
                <p><span style="font-size: 18px;">- A basic rate taxpayer earning under £17.5k could be entitled to even more. </span></p>
            </div>
            <div class="lp-element lp-pom-image" id="lp-pom-image-454">
                <div class="lp-pom-image-container" style="overflow: hidden;">
                <img src="<?php echo base_url();?>assets/images/img/img-001-desktop-1x.png" alt="" 
                data-src-desktop-1x="<?php echo base_url();?>assets/images/img/img-001-desktop-1x.png"
                data-src-mobile-1x="<?php echo base_url();?>assets/images/img/img-001-desktop-1x.png"
                data-src-mobile-2x="<?php echo base_url();?>assets/images/img/img-001-desktop-1x.png"></div>
            </div>
            <div class="lp-element lp-pom-image" id="lp-pom-image-455">
                <div class="lp-pom-image-container" style="overflow: hidden;">
                <img src="<?php echo base_url();?>assets/images/img/img-002-desktop-1x.png" alt="" 
                data-src-desktop-1x="<?php echo base_url();?>assets/images/img/img-002-desktop-1x.png" 
                data-src-mobile-1x="<?php echo base_url();?>assets/images/img/img-002-desktop-1x.png"
                data-src-mobile-2x="<?php echo base_url();?>assets/images/img/img-002-desktop-1x.png"></div>
            </div>
        </div>
        <div class="lp-element lp-pom-block" id="lp-pom-block-376">
            <div id="lp-pom-block-376-color-overlay"></div>
            <div class="lp-pom-block-content"></div>
        </div>
        <div class="lp-element lp-pom-block" id="lp-pom-block-381">
            <div id="lp-pom-block-381-color-overlay"></div>
            <div class="lp-pom-block-content"></div>
        </div>
        <div class="lp-element lp-pom-block" id="lp-pom-block-392">
            <div id="lp-pom-block-392-color-overlay"></div>
            <div class="lp-pom-block-content"></div>
        </div>
        <div class="lp-element lp-pom-block" id="lp-pom-block-423">
            <div id="lp-pom-block-423-color-overlay"></div>
            <div class="lp-pom-block-content"></div>
        </div>
    </div>
    <script async src="<?php echo base_url();?>assets/jquery/jquery-3.1.1.min.js" type="text/javascript"></script>
    <script async src="<?php echo base_url();?>assets/jquery/main.js" type="text/javascript"></script>
  
</body>
</html>