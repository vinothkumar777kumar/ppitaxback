<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Taxform extends CI_Controller {


	public function index()
	{
// 		$this->load->model('ppitax_model');
// $results=$this->ppitax_model->getdata();
// Passing values to view
$this->load->view('pages/taxform1',['result'=>$results]);
	}


}
