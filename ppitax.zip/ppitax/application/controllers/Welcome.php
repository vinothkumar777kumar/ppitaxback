<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url_helper');
        $this->load->library('form_validation');
        $this->load->model('Ppitax_model');
    

// if(!$this->session->flashdata('name')){
//     redirect(base_url());
// }

    }

	public function index()
	{
	
		$this->load->view('pages/index');
    }
    
    public function admin()
	{
        $this->load->view('pages/adminlogin');
        
    }
    public function dasboard(){  
        // if($name = $this->session->flashdata('name')) {
        //     echo $name;
        //     // return;
        // }else{
        //     echo 'eroor';
        //     // return;
        // }
        if($this->session->flashdata('name')){
            $data['res'] = $this->Ppitax_model->getusercount();
            $data['pers'] = $this->Ppitax_model->taxuser_personaldetails_count();
            // print_r(count($res));
            $this->load->view('pages/dasboard',$data); 
             $this->session->set_flashdata('name',  $this->session->flashdata('name'));
        }else{
            redirect(base_url());
        }
        
    }
    
    public function checkadmin(){
  
            $data = array(
                'user_name' => $this->input->post('user_name'),
                'password' => $this->input->post('password'));
            $res =  $this->Ppitax_model->checkadmin($data);
        //  print_r($res);
        //  return;    
          if($res){
             $this->session->set_flashdata('name',  $this->input->post('user_name'));
           redirect('welcome/dasboard');
          }else if($res == 0){
            $this->session->set_flashdata('error', 'Invalid user');
            redirect(base_url().'index.php/welcome/admin');
          }
        
    }

    public function view_tax(){
        if($this->session->flashdata('name')){
            $this->session->set_flashdata('name',  $this->session->flashdata('name'));
        // $res['data'] = $this->Ppitax_model->gettaxformdata();
        $res['data'] = $this->Ppitax_model->getusercount();
        // print_r($res['data']);
        // return;
        $this->load->view('pages/taxview',$res);
        }else{
            redirect(base_url());
        }
    }

    public function view_more($id){
        if($this->session->flashdata('name')){
            $this->session->set_flashdata('name',  $this->session->flashdata('name'));
        $res['data'] = $this->Ppitax_model->gettaxalldata($id);
        // print_r($res['data']);
        $this->load->view('pages/view_taxform',$res);
        }else{
            redirect(base_url());
        }
    }

	public function checkuser(){
        if($this->input->post('submit')){
		$data = array('name' => $this->input->post('name'),'phone' => $this->input->post('phone'),'email' => $this->input->post('email'));
        $res['data'] = $this->Ppitax_model->saveppitaxuser($data);
        // print_r($res);
		if($res){
            $this->session->set_userdata('username',  $this->input->post('name'));
            $this->session->set_userdata('success_msg', 'taxuser has been added successfully.');
            $this->load->view('pages/thankyou');
			// $this->load->view('pages/taxform1',$res);
		}else{
			$data['error_msg'] = 'Some problems occurred, please try again.';
			$this->load->view('pages/index');
        }
    }else{
        redirect(base_url());
    }
    }
    
    public function addformdata(){
        $this->form_validation->set_rules('fullname','Full Name','required');
        $this->form_validation->set_rules('dob','DOB','required');
        $this->form_validation->set_rules('phone','Phone Number','required');
        
        $this->form_validation->set_rules('address','Address','required');
        $this->form_validation->set_rules('postcode','postcode','required');
        $this->form_validation->set_rules('ninumber','NI number','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_error_delimiters('<div class="text-danger">','<div>');
        if($this->form_validation->run()){
		$data = array(
            'u_id' =>$this->input->post('u_id'),
            'fullname' => $this->input->post('fullname'),
            'dob' => $this->input->post('dob'),
            'phone' => $this->input->post('phone'),
            'sec_phone' => $this->input->post('sec_phone'),
            'address' => $this->input->post('address'),
            'postcode' => $this->input->post('postcode'),
            'ninumber' => $this->input->post('ninumber'),
            'email' => $this->input->post('email'));
        $res['data'] = $this->Ppitax_model->saveppitaxuserdetails($data);
        $data = array( 
            'u_id' =>$this->input->post('u_id'),
            'organisation1' => $this->input->post('organisation1'),
            'organisation1_date' => $this->input->post('organisation1_date'),
            'organisation1_ppiinterest' => $this->input->post('organisation1_ppiinterest'),
            'organisation1_statementattach' => $this->input->post('organisation1_statementattach'),
            'organisation2' => $this->input->post('organisation2'),
            'organisation2_date' => $this->input->post('organisation2_date'),
            'organisation2_ppiinterest' => $this->input->post('organisation2_ppiinterest'),
            'organisation2_statementattach' => $this->input->post('organisation2_statementattach'),
            'organisation3' => $this->input->post('organisation3'),
            'organisation3_date' => $this->input->post('organisation3_date'),
            'organisation3_ppiinterest' => $this->input->post('organisation3_ppiinterest'),
            'organisation3_statementattach' => $this->input->post('organisation3_statementattach'),
            'organisation4' => $this->input->post('organisation4'),
            'organisation4_date' => $this->input->post('organisation4_date'),
            'organisation4_ppiinterest' => $this->input->post('organisation4_ppiinterest'),
            'organisation4_statementattach' => $this->input->post('organisation4_statementattach'));
            $res['res'] = $this->Ppitax_model->saveppi_payout_details($data);
            $data = array( 
                'u_id' =>$this->input->post('u_id'),
                'year' => '2016-2017',
                'gross_table_income' => $this->input->post('gross_table_income_year1'),
                'banksaving_interst_received' => $this->input->post('interst_received_year1'),
                'other_interst_ppi' => $this->input->post('other_interst_ppi_year1'),
                'gross_known' => $this->input->post('gross_table_income_year1_known'),
                'bankinterst_known' => $this->input->post('interst_received_year1_none'),
                'other_ppi' => $this->input->post('other_interst_ppi_year1_none') );
                $res['res'] = $this->Ppitax_model->savtax_income_details($data);
            $data = array( 
                'u_id' =>$this->input->post('u_id'),
                'year' => '2017-2018',
                'gross_table_income' => $this->input->post('gross_table_income_year2'),
                'banksaving_interst_received' => $this->input->post('interst_received_year2'),
                'other_interst_ppi' => $this->input->post('other_interst_ppi_year2'),
                'gross_known' => $this->input->post('gross_table_income_year2_known'),
                'bankinterst_known' => $this->input->post('interst_received_year2_none'),
                'other_ppi' => $this->input->post('other_interst_ppi_year2_none') );
                $res['res'] = $this->Ppitax_model->savtax_income_details($data);
            $data = array( 
                'u_id' =>$this->input->post('u_id'),
                'year' => '2018-2019',
                'gross_table_income' => $this->input->post('gross_table_income_year3'),
                'banksaving_interst_received' => $this->input->post('interst_received_year3'),
                'other_interst_ppi' => $this->input->post('other_interst_ppi_year3'),
                'gross_known' => $this->input->post('gross_table_income_year3_known'),
                'bankinterst_known' => $this->input->post('interst_received_year3_none'),
                'other_ppi' => $this->input->post('other_interst_ppi_year3_none') );
                $res['res'] = $this->Ppitax_model->savtax_income_details($data);
            $data = array( 
                'u_id' =>$this->input->post('u_id'),
                'year' => '2019-2020',
                'gross_table_income' => $this->input->post('gross_table_income_year4'),
                'banksaving_interst_received' => $this->input->post('interst_received_year4'),
                'other_interst_ppi' => $this->input->post('other_interst_ppi_year4'),
                'gross_known' => $this->input->post('gross_table_income_year4_known'),
                'bankinterst_known' => $this->input->post('interst_received_year4_none'),
                'other_ppi' => $this->input->post('other_interst_ppi_year4_none') );
                $res['res'] = $this->Ppitax_model->savtax_income_details($data);
        // print_r($res);
		if($res){
			$this->session->set_flashdata('success_msg', 'Tax deatils has been added successfully.');
            // $this->load->view('pages/taxform1');
           
		}else{
			$data['error_msg'] = 'Some problems occurred, please try again.';
			// $this->load->view('pages/taxform1');
        }
        $this->load->view('pages/thankyou');
        // redirect(base_url());
       
    }else{
        // $this->load->view('pages/taxform1');
    }
    }
    
    public function logout(){  
        $this->session->sess_destroy();  
        redirect(base_url().'index.php/welcome/admin');
    }
}
