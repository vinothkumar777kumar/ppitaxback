-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2020 at 09:23 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppitax_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_income_details_tbl`
--

CREATE TABLE `bank_income_details_tbl` (
  `id` int(20) NOT NULL,
  `u_id` int(10) NOT NULL,
  `year` varchar(30) DEFAULT NULL,
  `gross_table_income` int(20) DEFAULT NULL,
  `banksaving_interst_received` int(20) DEFAULT NULL,
  `other_interst_ppi` int(20) DEFAULT NULL,
  `gross_known` int(10) DEFAULT NULL,
  `bankinterst_known` int(10) DEFAULT NULL,
  `other_ppi` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `taxuser`
--

CREATE TABLE `taxuser` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `taxuser_personaldetails`
--

CREATE TABLE `taxuser_personaldetails` (
  `id` int(10) NOT NULL,
  `u_id` int(20) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `sec_phone` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `postcode` varchar(30) NOT NULL,
  `ninumber` int(30) NOT NULL,
  `email` varchar(150) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `taxuser_ppipayou_details_tbl`
--

CREATE TABLE `taxuser_ppipayou_details_tbl` (
  `id` int(20) NOT NULL,
  `u_id` int(20) NOT NULL,
  `organisation1` varchar(200) NOT NULL,
  `organisation1_date` varchar(20) NOT NULL,
  `organisation1_ppiinterest` int(50) NOT NULL,
  `organisation1_statementattach` int(10) DEFAULT NULL,
  `organisation2` varchar(200) NOT NULL,
  `organisation2_date` varchar(20) NOT NULL,
  `organisation2_ppiinterest` int(50) NOT NULL,
  `organisation2_statementattach` int(10) DEFAULT NULL,
  `organisation3` varchar(200) NOT NULL,
  `organisation3_date` varchar(20) NOT NULL,
  `organisation3_ppiinterest` int(50) NOT NULL,
  `organisation3_statementattach` int(10) DEFAULT NULL,
  `organisation4` varchar(200) NOT NULL,
  `organisation4_date` varchar(20) NOT NULL,
  `organisation4_ppiinterest` int(50) NOT NULL,
  `organisation4_statementattach` int(10) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_income_details_tbl`
--
ALTER TABLE `bank_income_details_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxuser`
--
ALTER TABLE `taxuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxuser_personaldetails`
--
ALTER TABLE `taxuser_personaldetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxuser_ppipayou_details_tbl`
--
ALTER TABLE `taxuser_ppipayou_details_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_income_details_tbl`
--
ALTER TABLE `bank_income_details_tbl`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taxuser`
--
ALTER TABLE `taxuser`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taxuser_personaldetails`
--
ALTER TABLE `taxuser_personaldetails`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taxuser_ppipayou_details_tbl`
--
ALTER TABLE `taxuser_ppipayou_details_tbl`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
